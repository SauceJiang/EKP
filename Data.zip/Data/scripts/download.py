"""Download raw datasets into Data/raw/."""

from pathlib import Path

RAW_DIR = Path(__file__).resolve().parents[1] / "raw"


def main() -> None:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    # TODO: implement dataset downloads.


if __name__ == "__main__":
    main()
