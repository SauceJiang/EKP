"""Clean raw datasets and write to Data/interim/cleaned/."""

from pathlib import Path

INTERIM_CLEANED_DIR = Path(__file__).resolve().parents[1] / "interim" / "cleaned"


def main() -> None:
    INTERIM_CLEANED_DIR.mkdir(parents=True, exist_ok=True)
    # TODO: implement cleaning steps.


if __name__ == "__main__":
    main()
