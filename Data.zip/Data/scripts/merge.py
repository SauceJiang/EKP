"""Merge cleaned datasets into Data/interim/merged/ or Data/processed/modeling/."""

from pathlib import Path

INTERIM_MERGED_DIR = Path(__file__).resolve().parents[1] / "interim" / "merged"


def main() -> None:
    INTERIM_MERGED_DIR.mkdir(parents=True, exist_ok=True)
    # TODO: implement merging logic.


if __name__ == "__main__":
    main()
